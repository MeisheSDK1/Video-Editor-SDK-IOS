//
//  NvARSceneFxOperator.h
//  NvTest
//
//  Created by ms20180425 on 2022/8/19.
//

#import <Foundation/Foundation.h>
#import "NvARSceneAssetManager.h"

@class NvBeautyTypeModel;
@class NvMakeupEffectModel;


NS_ASSUME_NONNULL_BEGIN

@interface NvARSceneFxOperator : NSObject

/// sdk是否授权
@property (nonatomic, assign) BOOL verifySuccessful;

/// NvsEffectSdkContext上下文
@property (nonatomic, strong) NvsEffectSdkContext *effectContext;

/// NvsEffectRenderCore上下文
@property (nonatomic, strong) NvsEffectRenderCore *renderCore;

/// 人脸特效
@property (nonatomic, strong) NvsVideoEffect *faceEffect;

/// 美颜数据
@property (nonatomic, strong) NSMutableArray *beautyEffectArray;

/// 美型数据
@property (nonatomic, strong) NSMutableArray *beautyShapeArray;

/// 微整形数据
@property (nonatomic, strong) NSMutableArray *beautyMicroArray;

/// 美妆数据
@property (nonatomic, strong) NSMutableArray *beautyMakeupArray;

+ (NvARSceneFxOperator *)sharedInstance;

+ (void)dellocInstance;

/// 验证授权文件
/// @param lic 授权文件路径
- (void)verifySdkLicenseFile:(NSString *)lic;

/// 检测库是否带有人脸功能
+ (BOOL)hasARModule;

/// 初始化人脸模型
+ (BOOL)initARFace;

/// 创建人脸特效
- (void)creatARScene;

/// 初始化数据
- (void)setupData;

/// 应用美颜
/// @param model 模型
- (void)applicationBeautyEffect:(NvBeautyTypeModel *)model;

/// 对数组进行遍历，应用美颜的时候，同一类型特效只应用一种
/// @param model 模型
- (BOOL)applicationDefaultBeautyEffect:(NvBeautyTypeModel*)model;

/// 应用微整形
/// @param model 模型
- (void)applicationBeautyShapeAndMicro:(NvBeautyTypeModel *)model;

/// 应用美妆
/// @param model 模型
/// @param sing 是否是单妆
- (void)applicationMakeup:(NvMakeupEffectModel *)model withSingleMakeup:(BOOL)sing;

@end

NS_ASSUME_NONNULL_END
