//
//  NvARScenePreview.h
//  NvTest
//
//  Created by ms20180425 on 2022/8/23.
//

#import <UIKit/UIKit.h>
#import "NvARSceneFxOperator.h"

NS_ASSUME_NONNULL_BEGIN

@protocol NvARScenePreviewViewDelegate <NSObject>
@optional

/// 当外界需要自己创建滤镜特效，设置代理，并且实现代理方法，则滤镜不会在内部创建，需要由外部自己创建维护
/// @param dict 滤镜模型
- (void)filterDictionary:(NSDictionary *)dict;

/// 当外界需要自己创建校色滤镜特效，设置代理，并且实现代理方法，则滤镜不会在内部创建，需要由外部自己创建维护
/// @param dict 校色滤镜模型
- (void)correctionFilterDictionary:(NSDictionary *)dict;

/// 当外界需要自己创建美妆中的滤镜数组，设置代理，并且实现代理方法，则滤镜不会在内部创建，需要由外部自己创建维护
/// @param array
- (void)makeupFilterArray:(NSMutableArray *)array;

@end

@interface NvARScenePreview : UIView

@property (nonatomic, weak) id<NvARScenePreviewViewDelegate> delegate;

@property (nonatomic, strong) NvARSceneFxOperator *ARSceneFxOperator;

- (void)addBeautyView;

- (void)addFilterView;

- (void)addMakeupView;

- (void)showBeautyView:(BOOL)hidden;

- (void)showFilterView:(BOOL)hidden;

- (void)showMakeupView:(BOOL)hidden;
@end

NS_ASSUME_NONNULL_END
