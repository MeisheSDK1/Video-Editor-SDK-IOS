//
//  NvARSceneMacro.h
//  NvTest
//
//  Created by ms20180425 on 2022/8/19.
//

#ifndef NvARSceneMacro_h
#define NvARSceneMacro_h

#define USE_EFFECT_SDK

#define ARSCENE_ST240 NO
#define ARSCENE_ST106 NO

#define ARSCENE_MS106 NO
#define ARSCENE_MS240 YES

// 界面常用
#define SCREEN_WIDTH        [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT       [UIScreen mainScreen].bounds.size.height
#define SCREENSCALE [UIScreen mainScreen].bounds.size.width / 414.0
#define SCREENSCALEHEIGHT [UIScreen mainScreen].bounds.size.height / 896.0
#define StatusBarHeight ((SCREEN_HEIGHT >= 812.0) && [[UIDevice currentDevice].model isEqualToString:@"iPhone"] ?44:20)
#define SafeAreaTopHeight ((SCREEN_HEIGHT >= 812.0) && [[UIDevice currentDevice].model isEqualToString:@"iPhone"] ? 88 : 64)
#define SafeAreaBottomHeight ((SCREEN_HEIGHT >= 812.0) && [[UIDevice currentDevice].model isEqualToString:@"iPhone"]  ? 30 : 0)

#endif /* NvARSceneMacro_h */
